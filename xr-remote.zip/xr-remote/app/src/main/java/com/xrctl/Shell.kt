package com.xrctl

import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.lang.reflect.Method
import java.util.concurrent.Executors

/** Запуск shell-команд с правами shell через Shizuku. */
object Shell {
    private val newProcess: Method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    private val queue = Executors.newSingleThreadExecutor()

    fun state(): String = try {
        when {
            !Shizuku.pingBinder() -> "Shizuku не запущен"
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> "Нет разрешения Shizuku"
            else -> "OK"
        }
    } catch (e: Throwable) {
        "Shizuku не найден"
    }

    fun ready() = state() == "OK"

    /** Выполнить команду и вернуть вывод (блокирующий вызов, не из UI-потока). */
    fun run(cmd: String): String {
        val p = newProcess.invoke(
            null,
            arrayOf("sh", "-c", cmd),
            null as Array<String>?,
            null as String?
        ) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        return (out + err).trim()
    }

    /** Поставить команду в очередь (порядок сохраняется). */
    fun fire(cmd: String, onResult: ((String) -> Unit)? = null) {
        queue.execute {
            val r = try { run(cmd) } catch (e: Throwable) { "ERR: ${e.message}" }
            onResult?.invoke(r)
        }
    }
}

/** Команды управления внешним дисплеем. */
object Xr {
    fun tap(d: Int, x: Float, y: Float) = Shell.fire("input -d $d tap ${x.toInt()} ${y.toInt()}")

    fun swipe(d: Int, x1: Float, y1: Float, x2: Float, y2: Float, ms: Int = 250) =
        Shell.fire("input -d $d swipe ${x1.toInt()} ${y1.toInt()} ${x2.toInt()} ${y2.toInt()} $ms")

    fun longPress(d: Int, x: Float, y: Float) = swipe(d, x, y, x, y, 700)

    fun key(d: Int, code: Int) = Shell.fire("input -d $d keyevent $code")

    fun launch(d: Int, component: String, onResult: (String) -> Unit) =
        Shell.fire("am start --display $d -n $component", onResult)

    /** Способ 1: запуск самим приложением через ActivityOptions (из UI-потока). Возвращает "OK" или текст ошибки. */
    fun launchLocal(act: Activity, d: Int, pkg: String, cls: String): String = try {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(pkg, cls)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val options = ActivityOptions.makeBasic().setLaunchDisplayId(d)
        act.startActivity(intent, options.toBundle())
        "OK"
    } catch (e: Throwable) {
        "$e".take(400)
    }

    fun density(d: Int, dpi: Int) = Shell.fire("wm density $dpi -d $d")

    fun densityReset(d: Int) = Shell.fire("wm density reset -d $d")
}
