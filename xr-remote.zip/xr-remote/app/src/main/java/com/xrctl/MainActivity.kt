package com.xrctl

import android.app.Activity
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Display
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

private val BG = Color(0xFF0A0B12)
private val CARD = Color(0xFF151824)
private val CYAN = Color(0xFF00E5FF)
private val GREEN = Color(0xFF22E07A)
private val RED = Color(0xFFFF3B6B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    Modifier.fillMaxSize().systemBarsPadding(),
                    color = BG,
                    contentColor = Color.White
                ) {
                    App(this@MainActivity)
                }
            }
        }
    }
}

@Composable
fun App(act: Activity) {
    val dm = remember { act.getSystemService(DisplayManager::class.java) }
    var tab by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var selected by remember { mutableIntStateOf(-1) }

    DisposableEffect(dm) {
        val l = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) { tick++ }
            override fun onDisplayRemoved(displayId: Int) { tick++ }
            override fun onDisplayChanged(displayId: Int) { tick++ }
        }
        dm.registerDisplayListener(l, null)
        onDispose { dm.unregisterDisplayListener(l) }
    }

    val displays = remember(tick) { dm.displays.filter { it.displayId != Display.DEFAULT_DISPLAY } }
    val displayId = if (displays.any { it.displayId == selected }) selected
    else displays.firstOrNull()?.displayId ?: -1
    val shizuku = remember(tick) { Shell.state() }

    val (statusText, statusColor) = when {
        shizuku != "OK" -> "ERROR" to RED
        displayId < 0 -> "DISCONNECTED" to RED
        else -> "CONNECTED" to GREEN
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "XR REMOTE",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                maxLines = 1,
                softWrap = false
            )
            Text(
                statusText,
                color = statusColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(CARD)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
        TabRow(
            selectedTabIndex = tab,
            containerColor = CARD,
            contentColor = CYAN
        ) {
            listOf("SETUP", "APPS", "REMOTE").forEachIndexed { i, t ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    selectedContentColor = CYAN,
                    unselectedContentColor = Color.Gray,
                    text = {
                        Text(t, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
                    }
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            0 -> SetupTab(act, shizuku, displays, displayId, { selected = it }, { tick++ })
            1 -> AppsTab(act, displayId)
            else -> RemoteTab(act, dm, displayId)
        }
    }
}

@Composable
private fun CardBox(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(CARD)
            .padding(16.dp)
    ) { content() }
}

@Composable
private fun SetupTab(
    act: Activity,
    shizuku: String,
    displays: List<Display>,
    displayId: Int,
    onSelect: (Int) -> Unit,
    onRefresh: () -> Unit
) {
    var diag by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CardBox {
            Text("SHIZUKU", color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                if (shizuku == "OK") "Shizuku: доступ выдан" else "Shizuku: $shizuku",
                color = if (shizuku == "OK") GREEN else RED,
                fontSize = 18.sp
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    runCatching { Shizuku.requestPermission(100) }
                    onRefresh()
                }) { Text("Выдать доступ") }
                OutlinedButton(onClick = {
                    val i = act.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                    if (i != null) act.startActivity(i)
                    else Toast.makeText(act, "Shizuku не установлен", Toast.LENGTH_SHORT).show()
                }) { Text("Открыть Shizuku") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onRefresh) { Text("Обновить статус") }
        }

        CardBox {
            Text("ВНЕШНИЕ ДИСПЛЕИ", color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            if (displays.isEmpty()) {
                Text("Не найдено. Подключи очки по USB-C.", color = Color.Gray)
            }
            displays.forEach { d ->
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = d.displayId == displayId, onClick = { onSelect(d.displayId) })
                    Text(
                        "ID ${d.displayId} · ${d.name} · ${d.mode.physicalWidth}x${d.mode.physicalHeight}",
                        fontSize = 14.sp
                    )
                }
            }
            if (displayId >= 0 && shizuku == "OK") {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { Xr.densityReset(displayId) }) { Text("Сбросить масштаб") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    Shell.fire("settings put global force_resizable_activities 1") {
                        act.runOnUiThread {
                            Toast.makeText(
                                act,
                                "Включено. Если не помогло, перезагрузи телефон.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }) { Text("Разрешить любые приложения на очках") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    diag = "Запрос…"
                    Shell.fire(
                        "id; dumpsys display | grep -E 'mBaseDisplayInfo|DisplayDeviceInfo|rusted' | cut -c1-700"
                    ) { r -> act.runOnUiThread { diag = r.take(4000) } }
                }) { Text("Диагностика дисплея") }
            }
        }

        if (diag.isNotEmpty()) {
            CardBox {
                Text("ДИАГНОСТИКА (можно выделить и скопировать)", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                SelectionContainer { Text(diag, fontSize = 11.sp) }
            }
        }

        CardBox {
            Text("КАК ЭТО РАБОТАЕТ", color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "1. Включи беспроводную отладку и запусти Shizuku.\n" +
                    "2. Выдай этому приложению доступ.\n" +
                    "3. Подключи очки, выбери дисплей.\n" +
                    "4. Apps — запуск приложений на очках, Remote — трекпад.",
                fontSize = 14.sp
            )
        }
    }
}

private data class AppItem(
    val label: String,
    val pkg: String,
    val cls: String,
    val icon: ImageBitmap
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppsTab(act: Activity, displayId: Int) {
    val prefs = remember { act.getSharedPreferences("xr", Activity.MODE_PRIVATE) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var query by remember { mutableStateOf("") }
    var lastResult by remember { mutableStateOf("") }

    val apps by produceState(emptyList<AppItem>()) {
        value = withContext(Dispatchers.Default) {
            val pm = act.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(intent, 0).map {
                AppItem(
                    it.loadLabel(pm).toString(),
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()
                )
            }
        }
    }

    val shown = apps
        .filter { it.label.contains(query, ignoreCase = true) }
        .sortedWith(compareByDescending<AppItem> { it.pkg in favs }.thenBy { it.label.lowercase() })

    Column(Modifier.fillMaxSize()) {
        Text("ЗАПУСК НА ОЧКАХ (долгое нажатие — в избранное)", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("Поиск") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        if (lastResult.isNotEmpty()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CARD)
                    .padding(12.dp)
            ) {
                SelectionContainer {
                    Text(
                        lastResult.take(2000),
                        fontSize = 12.sp,
                        modifier = Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())
                    )
                }
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = { lastResult = "" }) { Text("Закрыть") }
            }
            Spacer(Modifier.height(8.dp))
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(shown, key = { it.pkg + "/" + it.cls }) { app ->
                Column(
                    Modifier
                        .padding(4.dp)
                        .combinedClickable(
                            onClick = {
                                if (displayId < 0 || !Shell.ready()) {
                                    Toast.makeText(act, "Нет дисплея или доступа Shizuku", Toast.LENGTH_SHORT).show()
                                } else {
                                    val local = Xr.launchLocal(act, displayId, app.pkg, app.cls)
                                    if (local == "OK") {
                                        lastResult = app.label + ": запуск отправлен (способ 1, из приложения)"
                                    } else {
                                        Xr.launch(displayId, app.pkg + "/" + app.cls) { r ->
                                            act.runOnUiThread {
                                                lastResult = app.label + ":\n[1] " + local + "\n[2] " + r
                                            }
                                        }
                                    }
                                }
                            },
                            onLongClick = {
                                favs = if (app.pkg in favs) favs - app.pkg else favs + app.pkg
                                prefs.edit().putStringSet("favs", favs).apply()
                            }
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(app.icon, contentDescription = null, modifier = Modifier.size(52.dp))
                    Text(
                        (if (app.pkg in favs) "★ " else "") + app.label,
                        fontSize = 11.sp,
                        maxLines = 2,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun RemoteTab(act: Activity, dm: DisplayManager, displayId: Int) {
    val display = remember(displayId) { if (displayId >= 0) dm.getDisplay(displayId) else null }
    if (display == null || !Shell.ready()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                "TRACKPAD MODE INACTIVE\nПодключи очки и запусти Shizuku",
                textAlign = TextAlign.Center,
                color = Color.Gray
            )
        }
        return
    }

    val metrics = remember(displayId) { DisplayMetrics().also { display.getRealMetrics(it) } }
    val w = metrics.widthPixels.toFloat()
    val h = metrics.heightPixels.toFloat()
    var pos by remember(displayId) { mutableStateOf(Offset(w / 2f, h / 2f)) }
    var dpi by remember(displayId) { mutableFloatStateOf(metrics.densityDpi.toFloat()) }

    val pres = remember(displayId) { runCatching { CursorPresentation(act, display) }.getOrNull() }
    DisposableEffect(pres) {
        runCatching { pres?.show() }
        onDispose { runCatching { pres?.dismiss() } }
    }
    LaunchedEffect(pres, pos) { pres?.view?.moveTo(pos.x, pos.y) }

    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(shape)
                .background(Color(0xFF05060B))
                .border(1.dp, Color(0xFF2A2D3A), shape)
                .pointerInput(displayId) {
                    detectTapGestures(
                        onTap = { Xr.tap(displayId, pos.x, pos.y) },
                        onLongPress = { Xr.longPress(displayId, pos.x, pos.y) }
                    )
                }
                .pointerInput(displayId) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        pos = Offset(
                            (pos.x + drag.x * 2.5f).coerceIn(0f, w - 1f),
                            (pos.y + drag.y * 2.5f).coerceIn(0f, h - 1f)
                        )
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                "ТРЕКПАД\nтап — клик, долгий тап — удержание",
                color = Color(0xFF3A3F55),
                textAlign = TextAlign.Center
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = {
                    Xr.swipe(displayId, pos.x, pos.y, pos.x, (pos.y + 400f).coerceAtMost(h - 1f))
                },
                modifier = Modifier.weight(1f)
            ) { Text("▲ вверх") }
            OutlinedButton(
                onClick = {
                    Xr.swipe(displayId, pos.x, pos.y, pos.x, (pos.y - 400f).coerceAtLeast(0f))
                },
                modifier = Modifier.weight(1f)
            ) { Text("▼ вниз") }
        }

        CardBox {
            Text("МАСШТАБ: ${dpi.toInt()} dpi", color = Color.Gray, fontSize = 12.sp)
            Slider(
                value = dpi,
                onValueChange = { dpi = it },
                onValueChangeFinished = { Xr.density(displayId, dpi.toInt()) },
                valueRange = 120f..640f
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("◀" to 4, "⌂" to 3, "▢" to 187, "⏯" to 85, "⏮" to 88, "⏭" to 87).forEach { (label, code) ->
                OutlinedButton(
                    onClick = { Xr.key(displayId, code) },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.weight(1f)
                ) { Text(label, fontSize = 18.sp) }
            }
        }
        Spacer(Modifier.height(4.dp))
    }
}
