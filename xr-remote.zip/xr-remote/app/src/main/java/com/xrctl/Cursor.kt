package com.xrctl

import android.app.Presentation
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Display
import android.view.View
import android.view.WindowManager

/** Курсор, нарисованный поверх внешнего дисплея. */
class CursorView(ctx: Context) : View(ctx) {
    private var cx = 0f
    private var cy = 0f
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val path = Path()

    fun moveTo(x: Float, y: Float) {
        cx = x
        cy = y
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        path.reset()
        path.moveTo(cx, cy)
        path.lineTo(cx, cy + 40f)
        path.lineTo(cx + 12f, cy + 30f)
        path.lineTo(cx + 26f, cy + 28f)
        path.close()
        canvas.drawPath(path, fill)
        canvas.drawPath(path, stroke)
    }
}

class CursorPresentation(ctx: Context, display: Display) : Presentation(ctx, display) {
    val view = CursorView(ctx)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            )
        }
        setContentView(view)
    }
}
